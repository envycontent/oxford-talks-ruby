class InitialData < ActiveRecord::Migration
  def self.up
   #u = User.find(:first) || User.new do |u|
	 #u.email = "tamc2@cam.ac.uk"
	 #u.name = "Tom Counsell"
	 #u.password = "not a good password"
	 #u.affiliation = "University of Cambridge"
	 #u.administrator = true
#	end.save

#	List.new do |l|
#		l.name = "Front page talks"
#		l.users << u
#	end.save unless List.find_by_name("Front page talks")
  end

  def self.down
	
  end
end
