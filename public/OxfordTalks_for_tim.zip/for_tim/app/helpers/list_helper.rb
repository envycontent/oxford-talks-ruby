module ListHelper
   def body_class
    'application list'
   end
end
