class LoginController < ApplicationController
end
