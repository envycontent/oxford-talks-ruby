# This is only used for legacy / imported listings
class Listing < List; end